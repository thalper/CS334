#define _USE_MATH_DEFINES
#include <cmath>
#include "shader.h"
#include "vertexarray2.h"
#include <GL/glut.h>
#include <GL/freeglut_ext.h>

class Point {
public:
  float x, y;

  Point (float x, float y) : x(x), y(y) {}
};

Point pos(0.0f, 0.0f);
float th = 0.0f;
Shader shader;
VertexArray va;

void setModel ()
{
  float r = M_PI*th/180.0, s = sin(r), c = cos(r),
    m[] = {c, - s, 0, pos.x,
	   s,   c, 0, pos.y,
	   0,   0, 1, 0,
	   0,   0, 0, 1};
  shader.setMat4("model", m);
}

void display ()
{
  glClear(GL_COLOR_BUFFER_BIT);
  shader.use();
  va.use();
  setModel();
  glDrawArrays(GL_TRIANGLES, 0, 3);
  glutSwapBuffers();
}

void reshape (int w, int h)
{
  glViewport(0, 0, w, h);
}

void keyboard (unsigned char key, int x, int y)
{
  switch (key) {
  case 'r':
    shader.setVec3("inColor", 1, 0, 0);
    break;
  case 'g':
    shader.setVec3("inColor", 0, 1, 0);
    break;
  case 'b':
    shader.setVec3("inColor", 0, 0, 1);
    break;
  case 'q':
    glutLeaveMainLoop();
  }
  glutPostRedisplay();
}

Point point (int x, int y)
{
  float u = x/float(glutGet(GLUT_WINDOW_WIDTH));
  float v = 1.0 - y/float(glutGet(GLUT_WINDOW_HEIGHT));
  return Point(2.0f*u - 1.0f, 2.0f*v - 1.0f);
}

void mouse (int button, int buttonState, int x, int y)
{
  if (buttonState == GLUT_DOWN)
    return;
  switch (button) {
  case GLUT_LEFT_BUTTON:
    th += 30.0;
    break;
  case GLUT_MIDDLE_BUTTON:
    pos = point(x, y);
    break;
  case GLUT_RIGHT_BUTTON:
    th -= 30.0f;
    break;
  }
  glutPostRedisplay();
}

void graphicsInit (unsigned int w, unsigned int h)
{
  int argc = 1;
  glutInit(&argc, 0);
  glutInitWindowSize(w, h);
  glutCreateWindow("triangle window");
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
  glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_GLUTMAINLOOP_RETURNS);
  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutKeyboardFunc(keyboard);
  glutMouseFunc(mouse);
  glClearColor(1.0, 1.0, 1.0, 0.0);
  glewInit();
}

int main (int argc, char **argv)
{
  int windowsize = 500;
  graphicsInit(windowsize, windowsize);
  shader = Shader("shader1.vs", "shader1.fs");
  float tr[] = {0, 0, .5, 0, 0, .5};
  va = VertexArray(3, tr);
  glutMainLoop();
  shader.free();
  va.free();
  return 0;
}
