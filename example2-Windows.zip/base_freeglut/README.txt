1. please download Visual Studio 2015 / 2017 (higher version should also work) to open the project;
2. if you have some linker issues with Freeglut, you could try downloading it at http://freeglut.sourceforge.net/;
3. GLM should not be used for this assignment.
